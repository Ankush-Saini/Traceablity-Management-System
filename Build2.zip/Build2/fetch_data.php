<?php
   
         
            $dbhost = '127.0.0.1'; 
            $dbuser = 'root'; 
            $dbpass = ''; 
            $conn = mysql_connect($dbhost, $dbuser, $dbpass); 
                         
            if(! $conn ) { 
               die('Could not connect: ' . mysql_error()); 
            } 
             mysql_select_db('se_project');
      

     
	
		$query = mysql_query("select * from project where Sys_Id='" . $_POST["s_id"] . "'");
		$resultset = array();
		while($row=mysql_fetch_array($query)) {
			$resultset[] = $row;
			}		
		if(!empty($resultset))
			$results = $resultset;
	
	 ?>
	<option value="126540001">Select Project Name</option>
<?php
	foreach($results as $state) {
?>
	<option value="<?php echo $state[1]; ?>"><?php echo $state[2]; ?>(<?php echo $state[1]; ?>)</option>
<?php
	}

?>