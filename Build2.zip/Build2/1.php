<?php
$t = $_GET['title'];
$file = 'downloads/'.$t.'.pdf';
header('Content-Disposition: attachment; filename='.basename($file));
header('Content-Type: application/pdf');
readfile($file);
?>