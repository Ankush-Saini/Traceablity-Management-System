<?php
$conn = mysqli_connect('localhost','root','','se_project');
if(!$conn)
{
	die(mysqli_error());
}

?>