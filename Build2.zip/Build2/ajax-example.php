
<?php
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
//$dbname = "software_eng";
$dbname = "se_project";
error_reporting(E_ALL ^ E_DEPRECATED); // remove warning of deprication
//Connect to MySQL Server
mysql_connect($dbhost, $dbuser, $dbpass);
	
//Select Database
mysql_select_db($dbname) or die(mysql_error());
	
// Retrieve data from Query String
$dname = $_GET['dname'];



if($dname != "none")
{	

//New Code
	$query = "select Project_id from baseline where R_id = '$dname'";
	$qry_result = mysql_query($query) or die(mysql_error());
	$row = mysql_fetch_array($qry_result);
	$projectId = $row['Project_id'];
	$length = strlen($projectId);
	$splitRid = str_split($dname,$length);
	$count = count($splitRid);
	if($count == 3)
	{
		$dname1 = $splitRid[1].$splitRid[2];
	}
	else
	{
		$dname1 = $splitRid[1];
	}
	
//build query

$query = "SELECT R_id,Timestamp,Pm_id,Description from baseline where R_id LIKE ('%$dname1.%') OR R_id LIKE ('$dname') order by Timestamp ";

//$query= "SELECT R_id,Timestamp,Pm_id,Description from baseline where R_id LIKE ('".$dname.".%')   order by Timestamp desc";
	
//Execute query


$qry_result = mysql_query($query) or die(mysql_error());
//Build Result String

$display_string = "<table cellpadding=5px;cellspacing=5px;>";
$display_string .= "<tr>";
$display_string .= "<th>Requirement ID</th>";
$display_string .= "<th>Last Updated</th>";
$display_string .= "<th>Project Manager</th>";
$display_string .= "<th>Description</th>";
$display_string .= "</tr>";
// EDIT
$count = 0;
// Insert a new row in the table for each person returned
while($row = mysql_fetch_array($qry_result)){
	//flag = true;
	$count++;
   $display_string .= "<tr>";
   $display_string .= "<td>$row[R_id]</td>";
   $display_string .= "<td>$row[Timestamp]</td>";
   $display_string .= "<td>$row[Pm_id]</td>";
   $display_string .= "<td>$row[Description]</td>";
   $display_string .= "</tr>";
}
$display_string .= "</table>";
$display_string .="<hr>";
$display_string .="<div class='first_div'>";
$display_string .="<form action='final_step.php' method='GET'>";
$display_string .="<fieldset>";
$display_string .="<legend> CHOOSE ANY ONE</legend><br>";
$display_string .="<div class='option1' id='opt1'>";
$display_string .="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='radio' id='select_one' name='options' value='nchanges' onclick = 'change1()'>N changes</input><br>";
$display_string .="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;enter the value of N:<input type='number' id='text_box1' name='changes' value='' min='0' max='$count'/>";
$display_string .="</div>";
$display_string .="<input type='hidden' name='dname1' value='$dname'>";	
$display_string .="<input type='hidden' name='counts' value='$count'>";	
$display_string .="<div class='option1' id='opt2'>";
$display_string .="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='radio' id='select_one' name='options' value='datechanges' onclick = 'change2()'>Date changes</input><br>";
$display_string .="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;From:<input type='date'  id='date1' name='from' onfocus='fromDate()'/><br>";
$display_string .='&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;To:<input type="date"  id="date2" name="to" onfocus="toDate()"/>';
$display_string .="</div>";
$display_string .='<div class="option1" id="opt3" >';
$display_string .='&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" id="select_one" name="options" value="forall" onclick = "change3()" >For all changes</input>';
$display_string .="</div>";
$display_string .="</fieldset>";

//$display_string .="</div>";
//$display_string .='<div class="second_div">';

$display_string .='<input type="submit" name="trace" id="trace1" value="TRACE" style="margin-left:400px; margin-top:15px; border-radius:5px;" />';
$display_string .="</form>";
$display_string .="</div>";
//$display_string .="</div>";

echo $display_string;
}
else
{
	echo "<label class='error'> * Select one requirement</label>";
}
?>