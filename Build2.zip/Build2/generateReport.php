<?php
//header file for sending mail
include('mail.php');
generate_pdf();

function generate_pdf()
	{
	require('extendedFPDF.php');
	require('connection.php'); //Database connection
	date_default_timezone_set("Asia/Kolkata");

	//Choice is staus of all items in project
	if($_POST['reportOption'] == "report")
	{
		$req = array();
		$requirement = array();
		$design = array();
		$deploymentStatus = array();
		$totalTestCountArray = array();
		$testCountArray = array();
		$testing = array();
		$codingStatus = array();
		$totalDesignCountArray = array();
		$designCountArray = array();
		$query = "select R_id,Description,status from baseline where R_id not like '%NFR%' and Project_id='".$_POST['projectId']."';";
		$result = $conn->query($query); //or die(mysql_error());
		
		//Get the Requirement Details
		while($row = $result->fetch_assoc())
		 {
			array_push($req,$row['R_id']);
			array_push($requirement,$row['Description']);
			if($row['status'] == "incomplete")
			{
				array_push($design,"ongoing");
			}
			else if($row['status'] == "complete")
			{
				array_push($design,"completed");
			}
			else
			{
				array_push($deploymentStatus,"ongoing");
			}
		}
	
		//Get Test Case Details
		for($i=0;$i<count($req);$i++)
		{	
			$totalTestCountQuery = "select count(*) as count from testcase t , project_testcase p where p.Requirement_Id ='".$req[$i]."'and t.Test_id = p.test_id and p.Project_id ='".$_POST['projectId']."';";
			$totalTestCount = $conn->query($totalTestCountQuery);
			$testCountQuery = "select count(*) as count from testcase t , project_testcase p where p.Requirement_Id ='".$req[$i]."'and t.status not in ('approved') and t.test_id = p.test_id and p.Project_id ='".$_POST['projectId']."';";
			$testCount = $conn->query($testCountQuery);
			while(($totalTestCountRow = $totalTestCount->fetch_assoc()) && ($testCountRow = $testCount->fetch_assoc()))
			{
				array_push($totalTestCountArray,$totalTestCountRow['count']);
				array_push($testCountArray,$testCountRow['count']);
			}
		}

		for($i=0;$i<count($req);$i++)
		{
			//Setting Test Case Status 
			if($totalTestCountArray[$i] != 0 && $testCountArray[$i] == 0)
			{
				$testing[$i] = "completed";
			}
			else
			{
				$testing[$i] = "ongoing";
			}
			
			//Setting Coding status
			if($totalTestCountArray[$i] == 0 )
			{
				$codingStatus[$i] = "ongoing";
			}
			else
			{
				$codingStatus[$i] = "completed";
			}
		}

		//Setting the Deployment Status
		for($i=0;$i<count($req);$i++)
		{
			if($design[$i]=="completed" && $testing[$i]=="completed")
			{
				$deploymentStatus[$i] = "completed";
			}
			else
			{
				$deploymentStatus[$i] = "ongoing";
			}

		}
		$pdf=new PDF_MC_Table();
		$pdf->AddPage();

		//Write Report as Heading
		$pdf->SetFont('Arial','B',40);
		$pdf->MultiCell(0,35,"Report",0,'C');

		//Draw a line
		$pdf->SetLineWidth(0.5);
		$pdf->Line($pdf->GetX(),$pdf->GetY() - 5,$pdf->GetPageWidth()- 10 ,$pdf->GetY() - 5);

		$query = "select proj_name from Project where proj_id ='".$_POST['projectId']."'";
		$result = $conn->query($query);
		$row = $result->fetch_assoc();
		$projectName = "Project Title         :    ".$row['proj_name'];


		$query = "select e.Emp_Name from employee e, project_pm p where e.Emp_id = p.Emp_id and p.Proj_id ='".$_POST['projectId']."'";
		$result = $conn->query($query);
		$row = $result->fetch_assoc();
		$projectManager = "Project Manager  :    ".$row['Emp_Name'];

		$reportDate = "Date                      :    ".date("d/m/y");
		$pdf->SetFont('Arial','B',16);
		$pdf->MultiCell(0,8,$projectName);

		$pdf->MultiCell(0,8,$projectManager);
		$pdf->MultiCell(0,8,$reportDate);
		$pdf->MultiCell(0,10,"");

		$pdf->SetLineWidth(0.2);
		//Table with 5 columns
		$pdf->SetWidths(array(60,30,30,30,30));
		$pdf->SetFont('Arial','B',16);
		$pdf->Row(array("Requirements","Design","Coding","Testing","Deploy"));

		$pdf->SetFont('Arial','',14);
		for($i=0;$i<count($requirement);$i++)
		{
			$pdf->Row(array($requirement[$i],$design[$i],$codingStatus[$i],$testing[$i],$deploymentStatus[$i]));
		}
		if($_POST['mailOption'] == 'false')
		{
			$pdf->Output('F','report.pdf');
		}
		else if($_POST['mailOption'] == 'true')
		{
			$pdf->Output('F','report.pdf');
			$attachment = "report.pdf";
			$to = $_POST['mailTo'];
			$cc = $_POST['mailCc'];
			$mailStatus = mailReport($to,$cc,$attachment);
			echo ($mailStatus);
		}
	}

	//Choice is modified items during selected dates
	else if($_POST['reportOption'] == "completedReport")
	{
		$pdf=new PDF_MC_Table();
		$pdf->AddPage();
		$contentPresent = false;
		
		//Write Report as Heading
		$pdf->SetFont('Arial','B',40);
		$pdf->MultiCell(0,35,"Report",0,'C');

		//Draw a line
		$pdf->SetLineWidth(0.5);
		$pdf->Line($pdf->GetX(),$pdf->GetY() - 5,$pdf->GetPageWidth()- 10 ,$pdf->GetY() - 5);

		$query = "select proj_name from Project where Proj_id ='".$_POST['projectId']."'";
		$result = $conn->query($query);
		$row = $result->fetch_assoc();
		$projectName = "Project Title          :    ".$row['proj_name'];

		$query = "select e.Emp_Name from employee e, project_pm p where e.Emp_id = p.Emp_id and p.Proj_id ='".$_POST['projectId']."'";
		$result = $conn->query($query);
		$row = $result->fetch_assoc();
		$projectManager = "Project Manager   :    ".$row['Emp_Name'];

		$reportFrom = "From                      :    ".$_POST['reportFrom'];
		$reportTo = "To                           :    ".$_POST['reportTo'];

		$pdf->SetFont('Arial','B',20);
		$pdf->MultiCell(0,10,"Modifications During Selected Dates",0,'C');
		$pdf->MultiCell(0,10,"",0,'C');

		$pdf->SetFont('Arial','B',16);
		$pdf->MultiCell(0,8,$projectName);

		$pdf->MultiCell(0,8,$projectManager);
		$pdf->MultiCell(0,8,$reportFrom);
		$pdf->MultiCell(0,8,$reportTo);
		$pdf->MultiCell(0,10,"");

		$pdf->SetFont('Arial','B',15);

		//Requirements completed during selected dates
		$functionRequirementQuery = "select Description from functional where Project_id='".$_POST['projectId']."' and Timestamp BETWEEN '".$_POST['reportFrom']."' and '".$_POST['reportTo']."'";
		$functionalRequirement = $conn->query($functionRequirementQuery); //or die(mysql_error());
		if($functionalRequirement->num_rows > 0)
		{
			$contentPresent = true;
			$pdf->MultiCell(0,8,"Requirements Submitted :");
			$pdf->SetFont('Arial','',15);
			$srNo = 0;
			while($row = $functionalRequirement->fetch_assoc())
			{
				$srNo++;	
				$pdf->MultiCell(0,8,"$srNo. ".$row['Description'],0,'L');
				
			}
		}
		
		//Non functional Requirements
		$nonfunctionRequirementQuery = "select Description from non_functional where Project_id='".$_POST['projectId']."' and Timestamp BETWEEN '".$_POST['reportFrom']."' and '".$_POST['reportTo']."'";
		$nonfunctionalRequirement = $conn->query($nonfunctionRequirementQuery); //or die(mysql_error());
		if($nonfunctionalRequirement->num_rows > 0)
		{
			$contentPresent = true;
			while($row = $nonfunctionalRequirement->fetch_assoc())
			{
				$srNo++;	
				$pdf->MultiCell(0,8,"$srNo. ".$row['Description'],0,'L');
				
			}
			$pdf->MultiCell(0,8,"",0,'L');
		}
		else
		{
			$pdf->MultiCell(0,8,"",0,'L');
		}

		//Design completed during selected dates
		$designQuery = "select filename from file where reqid in (select R_id from baseline where Project_id='".$_POST['projectId']."' ) and timestamp BETWEEN '".$_POST['reportFrom']."' and '".$_POST['reportTo']."'";
		$design = $conn->query($designQuery); //or die(mysql_error());
		if($design->num_rows > 0)
		{
			$contentPresent = true;
			$pdf->SetFont('Arial','B',15);
			$pdf->MultiCell(0,8,"Design Completed:");
			$pdf->SetFont('Arial','',15);
			$srNo = 0;
			while($row = $design->fetch_assoc())
			{
				$srNo++;	
				$pdf->MultiCell(0,8,"$srNo. ".$row['filename'],0,'L');
				
			}
			$pdf->MultiCell(0,8,"",0,'L');
		}

		//Defect registered during selected dates
		$testQuery = "select d.Defect_Description as Description from defect d, project_testcase p where p.Project_id='".$_POST['projectId']."' and d.Open_date BETWEEN '".$_POST['reportFrom']."' and '".$_POST['reportTo']."' and d.Test_Id = p.Test_Id and status in('open','in-progress')";
		$test = $conn->query($testQuery); //or die(mysql_error());
		if($test->num_rows > 0)
		{
			$contentPresent = true;
			$pdf->SetFont('Arial','B',15);
			$pdf->MultiCell(0,8,"Defect Registered :");
			$pdf->SetFont('Arial','',15);
			$srNo = 0;
			while($row = $test->fetch_assoc())
			{
				$srNo++;	
				$pdf->MultiCell(0,8,"$srNo. ".$row['Description'],0,'L');
			}
			$pdf->MultiCell(0,8,"",0,'L');
		}

		//Defect Solved during selected dates
		$testQuery = "select d.Defect_Description as Description from defect d, project_testcase p where p.Project_id='".$_POST['projectId']."' and d.Modified_date BETWEEN '".$_POST['reportFrom']."' and '".$_POST['reportTo']."' and d.Test_Id = p.Test_Id and status in('closed')";
		$test = $conn->query($testQuery); //or die(mysql_error());
		if($test->num_rows > 0)
		{
			$contentPresent = true;
			$pdf->SetFont('Arial','B',15);
			$pdf->MultiCell(0,8,"Defect Solved :");
			$pdf->SetFont('Arial','',15);
			$srNo = 0;
			while($row = $test->fetch_assoc())
			{
				$srNo++;	
				$pdf->MultiCell(0,8,"$srNo. ".$row['Description'],0,'L');
			}
			$pdf->MultiCell(0,8,"",0,'L');
		}

		if(!$contentPresent)
		{
			$pdf->SetFont('Arial','B',15);
			$pdf->MultiCell(0,8,"No Components were done during selected Dates");
		}

		//Store the report in local server
		if($_POST['mailOption'] == 'false')
		{

			$pdf->Output('F','report.pdf');
		}

		//mail the report is mail option is checked
		else if($_POST['mailOption'] == 'true')
		{
			$pdf->Output('F','report.pdf');
			$attachment = "report.pdf";
			$to = $_POST['mailTo'];
			$cc = $_POST['mailCc'];
			$mailStatus = mailReport($to,$cc,$attachment);
			echo ($mailStatus);
		}
	}
}

?>
