<?php
	require_once('mysql_connect_inc.php');	
	$sys_id = $_REQUEST['system_id'];
	$query = "SELECT * FROM project WHERE Sys_Id='$sys_id';";
	echo "<select id='projList' name='projList'>";
	$projects = array();
	if($query_run = mysql_query($query)){
			if(mysql_num_rows($query_run)==NULL){
			echo "<option value='NO PROJECT'>NO PROJECT </option></select>";
				die();
			}
			echo "<option value='SELECT PROJECT'>--Select Project-- </option></select>";
			while($query_row=mysql_fetch_array($query_run)){					
				echo "<option value='".$query_row['Proj_Id']."'>".$query_row['Proj_Name']."</option>";
				}
		echo "</select>";
	
	}
	else{
		echo "query failed";
	}
?>