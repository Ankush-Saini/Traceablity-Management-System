<?php
	session_start();
	if(strcmp($_SESSION['tm_userType'],'projectManager')==0){
		header("location:login.php");}
	elseif(!$_SESSION['tm_username']){
		header("location:login.php");
		}

	$conn = mysqli_connect('localhost','root','','se_project');
	if(!$conn)
	{
		//echo "connection unsuccessful";
		die(mysqli_connect_error());
	}
?>
<html>
<head>
	<title>VERSION MODELING </title>
	<link rel="stylesheet" type="text/css" href="pagelayout.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
	<script type="text/javascript" src="js/time.js"></script>
</head>

<body onload=display_ct();>	
	<header>
		<button id="logout" onClick="location.href ='logout1.php'">LOGOUT</button>
		<label id="name">Hi, <?php echo $_SESSION['tm_username'];?></label>
		<h1>VERSION MODELING (ADMIN)</h1>
	</header>
	<label id='time' ></label>
	<nav>
		<ul style="list-style:none;">
			<li><a href="home.php">Home</a></li>
			<li><a style="color:black;" href="<?php if($_SESSION['tm_userType'] == 'admin') echo "Admin_Version_Modeling.php"; else echo"Pm_Version_Modeling.php" ?>">Version Modeling</a></li>
			<li><a href="entry.php">Requirement Tracing</a></li>
			
		</ul>
	</nav>
	<div style="padding-left:350px;padding-top:100px;clear:both;display : table-cell;">
		<h2>Systems</h2>
	<ul>
	<?php
		$link = mysqli_connect('localhost', 'root', '','se_project');
		$query = mysqli_query($link,'select SM_SystemID, SM_SysName from system'); 
		while($row=$query->fetch_array())
		{	
    		echo "<li><input type=checkbox  id=$row[SM_SystemID]><label class=click  for=$row[SM_SystemID]>$row[SM_SysName]</label>
                <ul>";
    		$result1 = mysqli_query($link,"select proj_name, proj_id from project WHERE sys_id='$row[SM_SystemID]'");
			while($row1=$result1->fetch_array())
    		{
       			echo " <li><input type=checkbox id=$row1[proj_id]><label class=click  for=$row1[proj_id]>$row1[proj_name]</label>
                <ul>";
    			$result2 = mysqli_query($link,"SELECT r_id,  project_id FROM baseline WHERE project_id='$row1[proj_id]' and r_id not like '%NFR%'");
    			while($row2=mysqli_fetch_array($result2))
				{
					echo "
            			<li><input type=checkbox  id=$row2[r_id]><label class=click for=$row2[r_id]>$row2[r_id]</label>
                		<ul>";
    				$result3 = mysqli_query($link,"SELECT name, ur_id, project_id FROM use_case WHERE project_id='$row2[project_id]'");
					$result4 = mysqli_query($link,"select test_id from project_testcase WHERE requirement_id='$row2[r_id]'");
					$result7 = mysqli_query($link,"select fileid, filename from file where reqid='$row2[r_id]' ");
					echo"<li><input type=checkbox  id=des+$row2[project_id]+$row2[r_id]><label class=click for=des+$row2[project_id]+$row2[r_id]>Design</label><ul>";
					echo "
            			<li><input type=checkbox  id=use+$row2[project_id]+$row2[r_id]><label class=click  for=use+$row2[project_id]+$row2[r_id]>Use Cases</label>
               			 <ul>";
    				while($row3=mysqli_fetch_array($result3))
					{
						echo "
            			<li><input type=checkbox  id=$row3[ur_id]+$row2[project_id]+$row2[r_id]><label class=click  for=$row3[ur_id]+$row2[project_id]+$row2[r_id]>Use Case Name : $row3[name]</label>
               			 <ul>";
    					$result5 = mysqli_query($link,"SELECT usecase_diag FROM use_case WHERE ur_id='$row3[ur_id]' and project_id='$row3[project_id]'");
    					while($row5=mysqli_fetch_array($result5))
						{
							echo '<li><img src="data:image/jpeg;base64,'.base64_encode( $row5['usecase_diag'] ).'" width=60px height=60px/></li>';
						}
						echo"</ul>";
					}
					echo"</ul>";
					echo "
            			<li><input type=checkbox  id=file+$row2[project_id]+$row2[r_id]><label class=click  for=file+$row2[project_id]+$row2[r_id]>Files</label>
               			 <ul>";
					while($row7=mysqli_fetch_array($result7))
					{
						echo "
            			<li><label class=click>File ID : $row7[fileid]</label><li><label class=click>File Name : $row7[filename]</label>
               			 ";
					}
					echo "</ul></ul><li><input type=checkbox  id=test+$row2[project_id]+$row2[r_id]><label class=click for=test+$row2[project_id]+$row2[r_id]>Test Cases</label>";
					echo"<ul>";
					while($row4=mysqli_fetch_array($result4))
					{
						echo "
						<li><input type=checkbox  id=$row4[test_id]><label class=click for=$row4[test_id]>Test Id : $row4[test_id]</label>
						<ul>";
						$result6 = mysqli_query($link,"SELECT testcase_description, input, expected_output, actual_output, tester_id, status FROM testcase WHERE test_id='$row4[test_id]'");	
		 				while($row6=mysqli_fetch_array($result6))
						{
							echo " <li><label class=click>Desc : $row6[testcase_description]</label></li>
							<li><label class=click> Input : $row6[input]</label></li>
							<li><label class=click> Expected output : $row6[expected_output]</label></li>
							<li><label class=click> Actual Output : $row6[actual_output]</label></li>
							<li><label class=click> Tester Id : $row6[tester_id]</label></li>
							<li><label class=click> Status : $row6[status]</label></li>";
						}
						echo"</ul>";
					}
					echo"</ul></ul>";
				}
				echo"</ul>";
			}
			echo"</ul>";
		}
		mysqli_close($link);
	?>
	</ul>
	</div>
</body>
</html>