<?php
require_once('mysql_connect_inc.php');
session_start();
if(strcmp($_SESSION['tm_userType'],'projectManager')==0){
	header("location:login.php");}
elseif(!$_SESSION['tm_username']){
	header("location:login.php");
}

if(isset($_SESSION['requirements'])){
$Requirement = $_SESSION['requirements'];
$project_id = $_SESSION['project'];
$system_id = $_SESSION['SystemID'];
$projectDesc = $_SESSION['projDesc'];		
$emp_id = $_SESSION['ReqDesc'];
//look for test cases for the selected project system and requirement.
$TestCases = array(); // this array is going to hold all the testcases for all the requirements
$TestCaseDesc = array(); // this array is going to hold all the testcases for all the requirements
$ExpOutput = array(); // this array is going to hold all the testcases for all the requirements
$ActOutput = array(); // this array is going to hold all the testcases for all the requirements
$StatusOfRequirements=array();//Status of each requirement
$Design= array();
$DesignReqNames = array();
$DesignStatuses = array();
$query = "SELECT Status FROM project WHERE Sys_Id = '$system_id' AND Proj_Id='$project_id';";
if($query_run=mysql_query($query)){
	while($row=mysql_fetch_array($query_run)){
		$StatusOfProject = $row['Status'];
	}
}
foreach($Requirement as $Req){
$query = "SELECT Test_Id FROM project_testcase WHERE Project_Id = '$project_id' AND Requirement_Id = '$Req';";
$TestCase = array();
$TestCaseDescription = array();
$ExpectedOutput= array();
$ActualOutput=array();
$DesignReq = array();
$DesignReqName = array();
$DesignStatus = array();
if($query_run = mysql_query($query)){
			if(mysql_num_rows($query_run)!=NULL){
			while($query_row=mysql_fetch_array($query_run)){				
				array_push($TestCase,$query_row['Test_Id']);
				$TestID = $query_row['Test_Id'];
				$query1 = "SELECT * FROM testcase WHERE Test_Id = $TestID;";
				if($query1_run=mysql_query($query1)){
					if(mysql_num_rows($query1_run)!=NULL){
						while($query_row=mysql_fetch_array($query1_run)){
							array_push($TestCaseDescription,$query_row['Testcase_Description']);
							array_push($ExpectedOutput,$query_row['Expected_Output']);
							array_push($ActualOutput,$query_row['Actual_Output']);
						}
					}
				}
			}
		array_push($TestCases,$TestCase); 	
		array_push($TestCaseDesc,$TestCaseDescription); 	
		array_push($ExpOutput,$ExpectedOutput); 	
		array_push($ActOutput,$ActualOutput); 	
}
}
$query = "SELECT * FROM file WHERE reqid = '$Req'";
if($query_run = mysql_query($query)){
	if(mysql_num_rows($query_run)!=NULL){
		while($query_row= mysql_fetch_array($query_run)){
			array_push($DesignReq,$query_row['fileid']);
			array_push($DesignReqName,$query_row['filename']);
			array_push($DesignStatus,$query_row['status']);
		}
			array_push($Design,$DesignReq);
			array_push($DesignReqNames,$DesignReqName);
			array_push($DesignStatuses,$DesignStatus);
		
	}
}


$query = "SELECT Status FROM baseline WHERE Project_id = '$project_id' AND R_id = '$Req';";
if($query_run = mysql_query($query)){
	while($query_row = mysql_fetch_array($query_run)){
		array_push($StatusOfRequirements,$query_row['Status']);
	}
}
}
}
?>
<html>
<head>
<title>Admin_Home</title>
<style>
@import url(pagelayout.css); <!--User Defined Style of the HTML FIle-->
</style>
	<style type="text/css">
		section
		{
			position:absolute;
			top:100px;
			left:250px;
			width:1058px;
			height:525px;
			padding-left:50px;
			padding-top:10px;
		}
	</style>

<meta http-Equiv="Cache-Control" Content="no-cache" />
<meta http-Equiv="Pragma" Content="no-cache" />
<meta http-Equiv="Expires" Content="0" />

<script src="gojs/go.js"></script>
<script type="text/javascript">
function init(){
	//get project Details as JSON objects
	var projectID = "<?php echo $project_id;?>";
	var requirements = <?php echo json_encode($Requirement);?>;
	var TestCase = <?php echo json_encode($TestCases);?>;
	var StatusOfProject = "<?php echo $StatusOfProject;?>";
	var StatusOfRequirements = <?php echo json_encode($StatusOfRequirements);?>;
	var DescriptionProject = "<?php echo $projectDesc;?>";
	var RequirementDesc = <?php echo json_encode($emp_id);?>;
	var TestCaseDesc = <?php echo json_encode($TestCaseDesc);?>;
	var ExpectedOutput = <?php echo json_encode($ExpOutput);?>;
	var ActualOutput = <?php echo json_encode($ActOutput);?>;
	var DesignID = <?php echo json_encode($Design);?>;
	var DesignName = <?php echo json_encode($DesignReqNames);?>;
	var DesignStatus = <?php echo json_encode($DesignStatuses);?>;
	console.log(DesignID);
	console.log(TestCase);
	//make the NodeDataArray to give to gojs for construction
	var RequirementArray = [];
	var rootData = function(key,color,ProjDesc){
		this.key = key;
		this.color = color;
		this.Desc = ProjDesc;
	}
	var NodeDataArray = function(keys,parents,color,ReqDesc){
		this.key = keys;
		this.parent = parents;
		this.color = color;
		this.Desc = ReqDesc;
	}
	if(StatusOfProject=="pending")
		RequirementArray.push((new rootData("Proj ID: "+projectID,"red",DescriptionProject)));
	else if(StatusOfProject=="complete")
		RequirementArray.push((new rootData("Proj ID: "+projectID,"green",DescriptionProject)));
	//var counter is the counter for Requirements for a specific project
	var length = requirements.length;
	for(var counter=0;counter<length;counter++){
		if(StatusOfRequirements[counter]=="complete")
			RequirementArray.push((new NodeDataArray(requirements[counter],"Proj ID: "+projectID,"green","Employee ID:"+RequirementDesc[counter])));
		else if(StatusOfRequirements[counter]=="incomplete")
			RequirementArray.push((new NodeDataArray(requirements[counter],"Proj ID: "+projectID,"red","Employee ID:"+RequirementDesc[counter])));
			var IndexOfTestCase = "Test" + counter;
			IndexOfTestCase = IndexOfTestCase + 1;
			var IndexOfDesign = "Design" + counter;
			IndexOfDesign = IndexOfDesign + 1;
			var DefinitionTC = "TestCases for Requirement"+requirements[counter];
			var DefinitionDesign = "Design for Requirement"+requirements[counter];
			RequirementArray.push((new NodeDataArray(IndexOfTestCase,requirements[counter],"blue",DefinitionTC)));
			RequirementArray.push((new NodeDataArray(IndexOfDesign,requirements[counter],"blue",DefinitionDesign)));	
		var testCase = TestCase[counter];
		var ExpOutput = ExpectedOutput[counter];
		var DescriptionOfTestCase = TestCaseDesc[counter];
		var ActOutput = ActualOutput[counter];
		if(testCase==null);
		else{
		var NumberOfTestcases = testCase.length;
		//counter2 is the counter for testcases of a specific project
		for(var counter2=0;counter2<NumberOfTestcases;counter2++){		
		if(ExpOutput[counter2]==ActOutput[counter2]){
		RequirementArray.push((new NodeDataArray("TC ID :"+testCase[counter2],IndexOfTestCase,"green",DescriptionOfTestCase[counter2])));	
		}
		else{
		RequirementArray.push((new NodeDataArray("TC ID :"+testCase[counter2],IndexOfTestCase,"red",DescriptionOfTestCase[counter2])));	
		}
		}
		}
	var DesignReq = DesignID[counter];
	var DesignNameReq = DesignName[counter];
	var DesignStatusReq = DesignStatus[counter];
		
	if(DesignReq==null);
	else{
		var DesignLength = DesignReq.length;
		for(var counter3=0;counter3<DesignLength;counter3++){
			//alert(DesignReq[counter3]);
			if(DesignStatusReq[counter3]=="completed")
			{var DesignEach = new NodeDataArray("Design ID :"+DesignReq[counter3],IndexOfDesign,"green",DesignNameReq[counter3]);
			RequirementArray.push(DesignEach);
			}
		else{
			var DesignEach = new NodeDataArray("Design ID :"+DesignReq[counter3],IndexOfDesign,"red",DesignNameReq[counter3]);
			RequirementArray.push(DesignEach);
		}
			console.log(DesignEach);
			
		}
	}
}
	
	console.log(RequirementArray);
	//make the model
	var $ = go.GraphObject.make;
	var myDiagram = 
	$(go.Diagram,"myDiagramDiv",
	{
	initialContentAlignment:go.Spot.Center,
	layout:
	$(go.TreeLayout,{
		arrangement:go.TreeLayout.ArrangementVertical,
		angle:90,
		layerSpacing: 15, //distance between each layer(parent and child)
		nodeSpacing:15
	})
	});
	var Model = $(go.TreeModel);
	Model.nodeDataArray = RequirementArray;
	myDiagram.nodeTemplate  = 
			// define each Node
			$(go.Node, "Spot",
			{
				selectionObjectName: "PANEL",
				isTreeExpanded: false,
				isTreeLeaf: true
			},
			//nodes outer shape
			$(go.Panel,"Spot",
			{name:"PANEL"},
			$(go.Shape,"circle",new go.Binding("fill", "color"),{
				toolTip: 
				//this can be Spot also but making the adornment Auto automatically adjusts the size of the tootip
				//Adornment is almost similar to Panel we use ADornment because Tooltip is an instance of Adornment
				$(go.Adornment,"Auto",
					$(go.Shape,{fill:"#FFFFCC"}),
					$(go.TextBlock,{margin:4},
					new go.Binding("text","Desc"))		
				)
			}),
			$(go.TextBlock,{font:"12pt sans-serif", margin: 5},
            new go.Binding("text", "key")
			)
			),
			//expand and collapse button
			$("TreeExpanderButton",
			{
				width:20,height:20,alignment:go.Spot.TopRight
			}
			)
		)
		
	myDiagram.model = Model;
}
</script>
</head>
<body onload="init()"> 
	<header> 	
		<button id="logout" onClick="location.href ='logout1.php'">LOGOUT</button>
		<label id="name">Hi, <?php echo $_SESSION['tm_username'];?></label>
		<h1>MODEL GENERATION (ADMIN)</h1>
	</header>
<nav>
		<ul style="list-style:none;">
			<li><a href="home.php">Home</a></li>
			<li><a href="main.php" style="color:black">Generate Model</a></li>
		</ul>
</nav>
<section>
<div id="myDiagramDiv"></div>
<div style="position:absolute;top:50px;right:50px;border-left:2px solid black;padding-left:70px;">
		<table border="1" style="width:180px;">
			<th colspan="2">For Project Status:</th>
			<tr><td style="background:green;">&nbsp;&nbsp;&nbsp;&nbsp;</td><td align="center">Complete</td></tr>
			<tr><td style="background:red;">&nbsp;&nbsp;&nbsp;&nbsp;</td><td align="center">Pending</td></tr>
		</table>
		<br/>
		<table border="1" style="width:180px;">
			<th colspan="2">For Requirement Status:</th>
			<tr><td style="background:green;">&nbsp;&nbsp;&nbsp;&nbsp;</td><td align="center">Approved</td></tr>
			<tr><td style="background:red;">&nbsp;&nbsp;&nbsp;&nbsp;</td><td align="center">Disapproved</td></tr>
		</table><br/>
		<table border="1" style="width:180px;">
			<th colspan="2">For Design Status:</th>
			<tr><td style="background:green;">&nbsp;&nbsp;&nbsp;&nbsp;</td><td align="center">Approved</td></tr>
			<tr><td style="background:red;">&nbsp;&nbsp;&nbsp;&nbsp;</td><td align="center">Disapproved</td></tr>
		</table>
		<br/>
		<table border="1" style="width:180px;">
			<th colspan="2">For Test Status:</th>
			<tr><td style="background:green;">&nbsp;&nbsp;&nbsp;&nbsp;</td><td align="center">Success</td></tr>
			<tr><td style="background:red;">&nbsp;&nbsp;&nbsp;&nbsp;</td><td align="center">Failure</td></tr>
		</table>
		</div>
	</section>
</body>
</html>