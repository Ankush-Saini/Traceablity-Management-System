<?php
	session_start();
	if(strcmp($_SESSION['tm_userType'],'projectManager')==0){
		header("location:login.php");}
	elseif(!$_SESSION['tm_username']){
		header("location:login.php");
		}
?>
<html>
<head><title> version page</title>
<link rel="stylesheet" type="text/css" href="pagelayout.css">
<script src="jquery-1.12.3.min.js"></script>
<script>
		function toDate() {
            //Get today's date at midnight
            var from = document.getElementById('date1').value;
			var to = document.getElementById('date2').min = from;
            //Get the selected date (also at midnight)
        }
		function fromDate(){
			var to = document.getElementById('date2').value;
			var from = document.getElementById('date1').max = to;
		}
		function change1(){
			document.getElementById('text_box1').disabled = false;
			document.getElementById('date1').disabled = true;
			document.getElementById('date2').disabled = true;
		}
		function change2(){
			document.getElementById('text_box1').disabled = true;
			document.getElementById('date1').disabled = false;
			document.getElementById('date2').disabled = false;
		}
		function change3(){
			document.getElementById('text_box1').disabled = true;
			document.getElementById('date1').disabled = true;
			document.getElementById('date2').disabled = true;
		}
</script>
<script>
		function display_c()
		{
		var refresh=1000; // Refresh rate in milli seconds
		mytime=setTimeout('display_ct()',refresh)
		}

		function display_ct() 
		{
		var strcount
		var monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
		var d = new Date();
		var x = ("0" + d.getDate()).slice(-2) + " " + monthNames[d.getMonth()] + " - " + ("0" + d.getHours()).slice(-2) + 
		" : " + ("0" + d.getMinutes()).slice(-2)+ " : " + ("0" + d.getSeconds()).slice(-2);

		document.getElementById('time').innerHTML = x;
		tt=display_c();
		}
		function loadSystemDetails()
		{
		var xhttp;
    		xhttp = new XMLHttpRequest();
   			xhttp.onreadystatechange = function() {
	    		if (xhttp.readyState == 4 && xhttp.status == 200) 
	      		{
	        		document.getElementById("select_div").innerHTML = xhttp.responseText;
	      		}
    		};
     
	    	var url="populateSystemId.php";
	    	xhttp.open("GET", url, true);
	    	xhttp.send();
		
		}
		</script>
		
		<script type="text/javascript" src="http://ajax.googleapis.com/
ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script type="text/javascript">
// ajax code
function ajaxFunction(val)
{
   var ajaxRequest;  // The variable that makes Ajax possible!
   try{
   
      // Opera 8.0+, Firefox, Safari
      ajaxRequest = new XMLHttpRequest();
   }catch (e){
      
      // Internet Explorer Browsers
      try{
         ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
      }catch (e) {
         
         try{
            ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
         }catch (e){
         
            // Something went wrong
            alert("Your browser broke!");
            return false;
         }
      }
   }
   
   // Create a function that will receive data
   // sent from the server and will update
   // div section in the same page.
   ajaxRequest.onreadystatechange = function(){
   
      if(ajaxRequest.readyState == 4){
         var ajaxDisplay = document.getElementById('hello');
         ajaxDisplay.innerHTML = ajaxRequest.responseText;
      }
   }
   
   // Now get the value from user and pass it to
   // server script
   var queryString = "?dname=" + val ;
   ajaxRequest.open("GET", "ajax-example.php" + queryString, true);
   ajaxRequest.send(null); 
}
</script>
</head>

<body onload="display_c()">	
<div id="d1">
	<div id="siteHeader">
		<header>
			<button id="logout" onClick="location.href ='logout1.php'">LOGOUT</button>
			<label id="name">Hi, <?php echo $_SESSION['tm_username'];?></label>
			<h1>REQUIREMENT TRACING</h1>
		</header>
		<label id='time' ></label>
		<nav>
			<ul style="list-style:none;">
				<li><a href="home.php">Home</a></li>
				<li><a href="<?php if($_SESSION['tm_userType'] == 'admin') echo "Admin_Version_Modeling.php" ;else echo"Pm_Version_Modeling.php" ?>">Version Modeling</a></li>
				<li><a href="entry.php" style="color:black">Requirement Tracing</a></li>
			</ul>
		</nav>
	</div>
	

<div class="main_div">
<div><br><div/>
<div class="first_div" id="select_div">
<form autocomplete="off">
<fieldset>
<legend> CHOOSE ANY</legend><br>
 REQUIREMENT ID:
 <select onchange="ajaxFunction(this.value)" id="req">
   <option value="none" selected >--SELECT Requirement ID--</option>	
<?php
		   
             $host = 'localhost';
             $user = 'root';
             $pass = '';
			 error_reporting(E_ALL ^ E_DEPRECATED);     
             mysql_connect($host, $user, $pass);

             //mysql_select_db('software_eng');
			 mysql_select_db('se_project');
             // table name from where the we are getting the req.
             //$select=mysql_query("select R_id from baseline group by R_id");
			 $query = "select R_id from baseline WHERE R_id NOT LIKE '%.%';";
			 //echo "<option>$query</option>";
			 $select=mysql_query($query);
             while($row=mysql_fetch_array($select))
             {
              echo "<option>".$row['R_id']."</option>";
             }
?>
  
</select>
<br>
</fieldset>
</div>
<hr>
</form>
<div id="hello">INFORMATION</div>
</div>
</body>
</html>
