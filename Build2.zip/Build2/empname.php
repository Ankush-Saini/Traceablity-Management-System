<?php
$con = mysql_connect("localhost","root","");
mysql_select_db("se_project", $con);
?>

<!DOCTYPE HTML> 
<html>
<head>
<style>
@import"basic.css";
</style>
</head>
<body>
<form name="2" method="post" action="employee.php">
<label class="insideform">Employee Name</label>
	<input type="text" name="name"  value="" required class="getinsideForm">
<input type="submit" value="submit" class="button" name="submit"><br /><br />

</form>

</body>
</html>