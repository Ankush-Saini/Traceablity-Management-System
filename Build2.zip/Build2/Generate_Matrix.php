<?php
session_start();
if(strcmp($_SESSION['tm_userType'],'projectManager')==0){
	header("location:login.php");}
elseif(!$_SESSION['tm_username']){
header("location:login.php");
}
?>
<html>
<head>
	<title>Tracebility Management </title>
	<link rel="stylesheet" type="text/css" href="pagelayout.css">
    <script src="jquery-2.1.1.min.js" type="text/javascript"></script>
	<script>
		function display_c()
		{
		var refresh=1000; // Refresh rate in milli seconds
		mytime=setTimeout('display_ct()',refresh)
		}

		function display_ct() 
		{
		var strcount
		var monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
		var d = new Date();
		var x = ("0" + d.getDate()).slice(-2) + " " + monthNames[d.getMonth()] + " - " + ("0" + d.getHours()).slice(-2) + 
		" : " + ("0" + d.getMinutes()).slice(-2)+ " : " + ("0" + d.getSeconds()).slice(-2);

		document.getElementById('time').innerHTML = x;
		tt=display_c();
		}



	</script>
</head>
<?php
       
       
            $dbhost = '127.0.0.1'; 
            $dbuser = 'root'; 
            $dbpass = ''; 
            $conn = mysql_connect($dbhost, $dbuser, $dbpass); 
            $Pid=$_POST['pid'];
			$resultset = array();
			if(! $conn ) { 
               die('Could not connect: ' . mysql_error()); 
            } 
             mysql_select_db('se_project'); 
			 $query = "select * from project where Proj_Id='$Pid'";
			 $retval = mysql_query( $query, $conn );
			 $count=mysql_num_rows($retval);
			 if ($count == 0){
$sid='-';
$pid='-';
$pname='-';
$pdesc='-';
$sdate='-';
$endate='-';
$nhrs='-';
$teammbrs='-';
$status='-';

			 }  
			else{	 
            while ($r1 = mysql_fetch_row($retval)){
$sid=$r1[0];
$pid=$r1[1];
$pname=$r1[2];
$pdesc=$r1[3];
$sdate=$r1[4];
$endate=$r1[5];
$nhrs=$r1[6];
$teammbrs=$r1[7];
$status=$r1[8];
}
			}
$query1 = "select * from project_testcase where Project_Id='$Pid'";
			 $retval1 = mysql_query( $query1, $conn );
			 $count1=mysql_num_rows($retval1);
			 if ($count1==0){
				 $results[]='-';}
				 else{
			 while($row=mysql_fetch_array($retval1)) {
			$resultset[] = $row;
			}	
			 if(!empty($resultset))
			$results = $resultset;
				 }
$query2 = "select * from functional where Project_Id='$Pid'";
			 $retval2 = mysql_query( $query2, $conn );
			 $count2=mysql_num_rows($retval2);
			 if ($count2==0){
				 $results1[]='-';}
				 else{
			 while($row1=mysql_fetch_array($retval2)) {
			$resultset1[] = $row1;
			}	
			 if(!empty($resultset1))
			$results1 = $resultset1;
				 }
$query3 = "select * from non_functional where Project_Id='$Pid'";
			 $retval3 = mysql_query( $query3, $conn );
			 $count3=mysql_num_rows($retval3);
			 if ($count3==0){
				 $results2[]='-';}
				 else{
			 while($row2=mysql_fetch_array($retval3)) {
			$resultset2[] = $row2;
			}	
			 if(!empty($resultset2))
			$results2 = $resultset2;
				 }				
			date_default_timezone_set('Asia/Kolkata');			
             $today1 = date("d-m-Y");
			 $today = $today1.'_'.$Pid;
			 $now = date("d-m-Y H:i:s");
			       
     mysql_close($conn);
      ?>


<body onload=display_ct();>	
	<div id="siteHeader">
		<header>
			<button id="logout" onClick="location.href ='logout1.php'">LOGOUT</button>
			<label id="name">Hi, <?php echo $_SESSION['tm_username'];?></label>
			<h1>Traceability Matrix for Administrator</h1>
		</header>
		<label id='time' ></label>
		<nav>
			<ul style="list-style:none;">
				<li><a href="home.php">Home</a></li>
				<li><a href="<?php if($_SESSION['tm_userType'] == 'admin') echo "Matrix_selection.php"; else echo "matrix.php" ?>" style="color:black">Tracebility Matrix</a></li>
				<li><a href="functional_requirements.php">View Requirements</a></li>
				<li><a href="testcase.php">View Test case</a></li>
				<li><a href="employees.php" >View Employees</a></li>
			</ul>
		</nav>
	</div>

	<br><br><br><br><br>
		<div id="section"><center>
        <?php ob_start(); ?>
<br><br>
<h3>Project ID: <?php echo $Pid; ?></h3>
    <h3>System ID:  <?php echo $sid; ?></h3>
    <h3>Project Name: <?php echo $pname; ?></h3>
    <h3>Matrix Generation  Timestamp : <?php echo $now; ?></h3>
    <div class="center">

<table width="100%" border="1">
<tr>
    <td style="text-align:center; font-weight:bold;">System ID</td>
    <td style="text-align:center; font-weight:bold;">Project ID</td>
	<td style="text-align:center; font-weight:bold;">Project name</td>
	<td style="text-align:center; font-weight:bold;">Project Description</td>
    <td style="height:100px; text-align:center; font-weight:bold;">Requirement ID</td>
    <td style="text-align:center; font-weight:bold;">Test Case ID(Req. ID)</td>
    <td style="text-align:center; font-weight:bold;">Start Date</td>
    <td style="text-align:center; font-weight:bold;">End Date</td>
    <td style="text-align:center; font-weight:bold;">No. of Team Members</td>
	<td style="text-align:center; font-weight:bold;">No. of hours</td>
	<td style="text-align:center; font-weight:bold;">Status</td>
      </tr>
  <tr>
  <td style="text-align:center;"><?php echo $sid; ?></td>
    <td style="text-align:center;"><?php echo $pid; ?></td>
	<td style="text-align:center;"><?php echo $pname; ?></td>
	<td style="text-align:center;"><?php echo $pdesc; ?></td>
    <td style="text-align:center;">
	<?php  if ($count2 ==0){ 
	echo $results1[0];
	} 
	else {foreach($results1 as $s1) {echo $s1[1];?> <br><br><?php }} ?> <br><br><?php if ($count3 ==0){ 
	echo $results2[0];
	} 
	else {
		  foreach($results2 as $s2) {	
		 echo $s2[1];?> <br><br><?php }
		 } ?>
   </td>
  
    <td style="text-align:center;">
	<?php if ($count1 ==0){ 
	echo $results[0];
	} 
	else {foreach($results as $s) {
		echo $s[0].'('.$s[2].')';?> <br><br><?php }} ?>
	</td>
  
  <td style="text-align:center;"><?php echo $sdate; ?></td>
  <td style="text-align:center;"><?php echo $endate; ?></td>
    <td style="text-align:center;">
	<?php echo $teammbrs; ?>
   </td>
  <td style="text-align:center;"><?php echo $nhrs; ?> </td> 
  <td style="text-align:center;"><?php echo $status; ?> </td>
  
 </tr>
</table>
<?php $mytable = ob_get_contents();?><div id="header">
 <br><br><br>
<input name="Download" type="button" value="Download as .pdf" class="button1" onClick="location.href ='1.php?title=<?php echo $today; ?>'" style="margin-bottom:30px; float:left;">
<input name="gen_modelback" type="button" value="Go Back" class="button1" onClick="location.href ='Matrix_selection.php'" style="float:right" style="margin-bottom:30px;">
<?php

if(isset($_POST['pid']))
{
    require_once("dompdf/dompdf_config.inc.php");
    $dompdf = new DOMPDF();
    $dompdf->load_html($mytable);
    $dompdf->set_paper("a3","landscape");
    $dompdf->render();
    $output = $dompdf->output();
    file_put_contents("downloads/$today.pdf",$output);
}
 ?>

  </div>
</center>
</div
	></div>
</body>
</html>