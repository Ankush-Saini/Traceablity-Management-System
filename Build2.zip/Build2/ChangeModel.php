<!-- Back-end work -->

<?php
// Start the session
session_start();
if(strcmp($_SESSION['tm_userType'],'projectManager')==0){
    header("location:login.php");}
  elseif(!$_SESSION['tm_username']){
    header("location:login.php");
    }
//Connection with the databases se_project
$con = mysql_connect("localhost","root","");
        mysql_select_db("se_project");
        $tnr = array();//number of testcases
        $tid = array();//testcases ids
        $tdes = array();//testcases description

        $dnr = array();//number of designs
        $fid = array();//design ids
        $fname = array();//design names


        //retrieving data from tables and storing in array 
        for($i=0;$i<$_SESSION['total'];$i++)
        { 

        $res = mysql_query("select testcase.Test_Id, testcase.Testcase_Description from project_testcase, testcase where project_testcase.Test_Id=testcase.Test_Id and project_testcase.Requirement_Id='".$_SESSION['req_arr'][$i]."'", $con);
            array_push($tnr,mysql_num_rows($res));

            while($r = mysql_fetch_row($res))
          {
                 array_push($tid,$r[0]);
               array_push($tdes,$r[1]); 
          }
        }

        //retrieving data from tables and storing in array 
        for($i=0;$i<$_SESSION['total'];$i++)
        { 

        $res = mysql_query("select fileid, filename from file where file.reqid='".$_SESSION['req_arr'][$i]."'", $con);
            array_push($dnr,mysql_num_rows($res));

            while($r = mysql_fetch_row($res))
          {
                 array_push($fid,$r[0]);
               array_push($fname,$r[1]); 
          }
        }
?>

<!-- Display of model starts here -->

<!DOCTYPE html>
<html>
<head>
<title>Change Model </title>

<!-- importing style sheets -->
<link rel="stylesheet" type="text/css" href="DataInspector.css">
<link rel="stylesheet" type="text/css" href="pagelayout.css">

<!-- importing script files -->
<script type="text/JavaScript" src="go-debug.js"></script>
<script type="text/JavaScript" src="DataInspector.js"></script>


<!-- script file from model generation -->
<script>

function init() {
    
    var $ = go.GraphObject.make;  // for conciseness in defining templates in this function

    myDiagram =
      $(go.Diagram, "myDiagramDivVersion",  // must be the ID or reference to div
        { initialContentAlignment: go.Spot.Center ,
          "undoManager.isEnabled":true,
          layout: $(go.TreeLayout, {layerSpacing: 70})
        });

    // define the Node template for non-terminal nodes
    myDiagram.nodeTemplate =
      $(go.Node, "Auto",
        { isShadowed: true,
          isTreeExpanded: false
         },
        // define the node's outer shape
        $(go.Shape, "RoundedRectangle",
          new go.Binding("fill", "color")),
        // define the node's text
        $(go.TextBlock,
          { margin: 13, stroke:"darkblue" },
          new go.Binding("text", "key")),
        $("TreeExpanderButton",{alignment:go.Spot.TopRight})
      );

     
      //Converting php array to js array by making json object

      var req_arr = <?php echo json_encode($_SESSION['req_arr']);?>;
      var total = "<?php echo json_encode($_SESSION['total']); ?>";
      var tnr = <?php echo json_encode($tnr);?>;
      var tid = <?php echo json_encode($tid);?>;
      var tdes = <?php echo json_encode($tdes);?>;
      var dnr = <?php echo json_encode($dnr);?>;
      var fid = <?php echo json_encode($fid);?>;
      var fname = <?php echo json_encode($fname);?>;

      var x,i,j=0,k=0;
      
      //creating js array object
      var changearray = [];
      for(x=0; x<total;x++)
      {
          //pushing gojs object in changearray
          //display requirement box
          changearray.push({key:req_arr[x], color:"#44A0B9",Description:"Expand to see testcases & designs"});
          //display testcases n designs box
          changearray.push({key:"TestCases_"+req_arr[x], parent:req_arr[x],color:"#D15082",Description:"Expand to see testcases"});
          changearray.push({key:"Designs_"+req_arr[x], parent:req_arr[x] ,color:"#7FB17D",Description:"Expand to see designs"});
          
          for(i=0;i<tnr[x];i++,j++)
          {
              changearray.push({key:"Test ID : "+tid[j], parent:"TestCases_"+req_arr[x],Description:tdes[j],color:"#E7E7E7"});
          }
          for(i=0;i<dnr[x];i++,k++)
          {
              changearray.push({key:"Design ID : "+fid[k]+" ", parent:"Designs_"+req_arr[x],Description:fname[k],color:"#E7E7E7"});
          }
          
      }    



    // define the Link template
    myDiagram.linkTemplate =
      $(go.Link,  // the whole link panel
        { selectable: false },
        $(go.Shape));  // the link shape

    //connecting the gojs model
    myDiagram.model = new go.TreeModel(changearray);


    // side inspector window
    var inspector = new Inspector('myInspector', myDiagram,
      {
        // uncomment this line to only inspect the named properties below instead of all properties on each object:
        // includesOwnProperties: false,
        properties: {
          // key would be automatically added for nodes, but we want to declare it read-only also:
          "key": { readOnly: true, show: Inspector.showIfPresent },
          // Comments and LinkComments are not in any node or link data (yet), so we add them here:
          "Description": { readOnly: true, show: Inspector.showIfNode  },
          
          "LinkComments": { readOnly: true, show: Inspector.showIfLink },
          // color would be automatically added for nodes, but we want to declare it a color also:
          "color": { show: Inspector.showIfPresent, type: 'color' },
        }
      });

     myDiagram.select(myDiagram.nodes.first());

}
  </script>

  </head>

<body onload="init()">

<header>

    <button id="logout" onclick="location.href ='logout1.php'">LOGOUT</button>
    <label id="name">Hi, <?php echo $_SESSION['tm_username'];?></label>
    <h1>REQUIREMENT TRACING</h1>

  </header>

  <label id='time' ></label>                                                                                                                                                                                                                  
  <nav>
    <ul style="list-style:none;">
      <li><a href="home.php">Home</a></li>
      <li><a href="<?php if($_SESSION['tm_userType'] == 'admin') echo "Admin_Version_Modeling.php"; else echo"Pm_Version_Modeling.php" ?>">Version Modeling</a></li>
      <li><a href="entry.php" style="color:black;" >Requirement Tracing</a></li>
    </ul>
  </nav>
<!--   displaying model window -->
    <div id="sample" style="margin-left:300px;" >
    <span style="display: inline-block;height:570px">
      <div style="margin-left: 60px; margin-top: 175px;">
        <div id="myDiagramDivVersion" ></div>
      </div>
    </span>
    <span >
      <div id="myInspector" class="inspector-container" style="margin-left:750px;top:-100px;"> </div>
    </span>
    

</body>
</html>
