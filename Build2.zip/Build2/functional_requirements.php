
<?php
session_start();
if(!isset($_SESSION["tm_username"]))
	{
		header("Location: login.php");
	}
$con = mysql_connect("localhost","root","");
mysql_select_db("se_project", $con);
	
	?>
<html>
<head>
	<title>Tracebility Management </title>
	<link rel="stylesheet" type="text/css" href="pagelayout.css">


	<script>
		function display_c()
		{
		var refresh=1000; // Refresh rate in milli seconds
		mytime=setTimeout('display_ct()',refresh)
		}

		function display_ct() 
		{
		var strcount
		var monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
		var d = new Date();
		var x = ("0" + d.getDate()).slice(-2) + " " + monthNames[d.getMonth()] + " - " + ("0" + d.getHours()).slice(-2) + 
		" : " + ("0" + d.getMinutes()).slice(-2)+ " : " + ("0" + d.getSeconds()).slice(-2);

		document.getElementById('time').innerHTML = x;
		tt=display_c();
		}

	</script>
		<script src="ab1.js"></script>
</head>

<body onload=display_ct();>	
	<div id="siteHeader">
		<header>
			<button id="logout" onClick="location.href ='logout1.php'">LOGOUT</button>
			<label id="name">Hi, <?php echo $_SESSION['tm_username'];?></label>
			<h1>FUNCTIONAL REQUIREMENTS</h1>
		</header>
		<label id='time' ></label>
		<nav>
			<ul style="list-style:none;">
				<li><a href="home.php">Home</a></li>
				<li><a href="<?php if($_SESSION['tm_userType'] == 'admin') echo "Matrix_selection.php"; else echo"matrix.php" ?>">Tracebility Matrix</a></li>
				<li><a href="functional_requirements.php" style="color:black">View Requirements</a></li>
				<li><a href="testcase.php">View Test case</a></li>
				<li><a href="employees.php">View Employees</a></li>
			</ul>
		</nav>
	</div>

	<div id="report" style="z-index: 999; width: 800px;display: block; position:absolute ;margin-top: 120px;margin-left:300px"><center>
	
<form method="post"> 
	
<div id="system">
<label class="insideForm">Search By:</label>
<select class="getInsideForm" name="users" onChange="showUser(this.value) ">
<option value="">Functional</option>
<option value="3">Reqirement ID</option>
<option value="4">Employee ID</option>
<option value="5">Requirement status</option>
</select>
</div>

<p>
<div id="txtHint"><b></b></div>
</p>
<div style="margin-left:200px">
<?php
	if($_SESSION['tm_userType'] == 'admin')
	{
		$locate=mysql_query("select * from functional");
		$categ = false;
		$zen = true;

		if(isset($_POST['ID1']))
		{
		$categ = $_POST['ID1'];
		$locate=mysql_query("select * from functional where FR_id like '$categ'");}

		if(isset($_POST['name']))
		{
		$categ = $_POST['name'];
		$locate=mysql_query("select * from functional where Emp_id like '$categ'");}

		if(isset($_POST['stat']))
		{
		$categ = $_POST['stat'];
		$locate=mysql_query("select * from functional where Status like '$categ'");}

		$count=mysql_num_rows($locate);
		if($count<=0)
		{
		echo '<i style="color:red;font-size:20px;font-family:arial ;">
		Searched items are not present or value entered is wrong. </i> ';
		$zen = false;
		}

		if($zen == true)
		{
		echo "<table border=1 id='tab' width='80%' cellpadding=0 cellspacing=0";
		echo "<tr>";
		echo "<th>Project ID</th>";
		echo "<th>Req. ID</th>";
		echo "<th>Employee ID</th>";
		echo "<th>Type</th>";
		echo "<th>Description</th>";
		echo "<th>Status</th>";
		echo "</tr>";
		}


		if($locate == FALSE) { 
		die("Error");}
		while($rows=mysql_fetch_array($locate)){
		echo "<tr>";
		echo "<td>".$rows['Project_id']."</td>";
		echo "<td>".$rows['FR_id']."</td>";
		echo "<td>".$rows['Emp_id']."</td>";
		echo "<td>".$rows['Type']."</td>";
		echo "<td>".$rows['Description']."</td>";
		echo "<td>".$rows['Status']."</td>";
		echo "</tr>";}
		echo "</table>";
	}
	else if($_SESSION['tm_userType'] == 'projectManager')
	{
		$project = "select Proj_id from project_pm where Emp_Id = '".$_SESSION['tm_userID']."'";
		$result = mysql_query($project);
		$row = mysql_fetch_array($result);
		$projectId = $row['Proj_id'];
		$locate=mysql_query("select * from functional where Project_id = '".$projectId."'");
		$categ = false;
		$zen = true;

		if(isset($_POST['ID1']))
		{
		$categ = $_POST['ID1'];
		$locate=mysql_query("select * from functional where FR_id like '$categ' and Project_id = '".$projectId."'");}

		if(isset($_POST['name']))
		{
		$categ = $_POST['name'];
		$locate=mysql_query("select * from functional where Emp_id like '$categ' Project_id = '".$projectId."'");}

		if(isset($_POST['stat']))
		{
		$categ = $_POST['stat'];
		$locate=mysql_query("select * from functional where Status like '$categ' and Project_id = '".$projectId."'");}

		$count=mysql_num_rows($locate);
		if($count<=0)
		{
		echo '<i style="color:red;font-size:20px;font-family:arial ;">
		Searched items are not present or value entered is wrong. </i> ';
		$zen = false;
		}

		if($zen == true)
		{
		echo "<table border=1 id='tab' width='80%' cellpadding=0 cellspacing=0";
		echo "<tr>";
		echo "<th>Project ID</th>";
		echo "<th>Req. ID</th>";
		echo "<th>Employee ID</th>";
		echo "<th>Type</th>";
		echo "<th>Description</th>";
		echo "<th>Status</th>";
		echo "</tr>";
		}	


		if($locate == FALSE) { 
		die("Error");}
		while($rows=mysql_fetch_array($locate)){
		echo "<tr>";
		echo "<td>".$rows['Project_id']."</td>";
		echo "<td>".$rows['FR_id']."</td>";
		echo "<td>".$rows['Emp_id']."</td>";
		echo "<td>".$rows['Type']."</td>";
		echo "<td>".$rows['Description']."</td>";
		echo "<td>".$rows['Status']."</td>";
		echo "</tr>";}
		echo "</table>";
	}
?>
<br><br>
</div>
<input type="submit" class="button" name="submit" value="Display Database" onmouseover="this.style.cursor=\'pointer\';" OnMouseOut="this.style.cursor=\'default\';">
<?php
if(isset($_POST['submit'])){
	if($_SESSION['tm_userType'] == 'admin')
	{
           $categ = $_POST['submit'];
		   $locate=mysql_query("select * from functional");
	}
	else if($_SESSION['tm_userType'] == 'projectManager')
	{
		$categ = $_POST['submit'];
		   $locate=mysql_query("select * from functional where Project_id = '".$projectId."'");
	}

}

		   ?>

<input type="button" class="button" onClick="parent.location='non_functional.php'" value="Open Non Functional">
</div>
</form>

</body>
</html>
