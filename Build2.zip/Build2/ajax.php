<!DOCTYPE html>
<html>
<head>
<style>
table {
    width: 100%;
    border-collapse: collapse;
}

table, td, th {
    border: 1px solid black;
    padding: 5px;
}

th {text-align: left;}
</style>
</head>
<body>

<?php
$q = intval($_GET['q']);
if($q==1)
{include"empid.php";}
if($q==2)
{include"empname.php";}
if($q==3)
{include"reqid.php";}
if($q==4)
{include"reqempname.php";}
if($q==5)
{include"reqstatus.php";}
if($q==6)
{include"testid.php";}
if($q==7)
{include"testerid.php";}
if($q==8)
{include"testresult.php";}
if($q==9)
{include"nfreq.php";}
if($q==10)
{include"nfempname.php";}
if($q==11)
{include"nfstatus.php";}
?>


</body>
</html