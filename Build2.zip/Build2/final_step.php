<?php
session_start();
// for last n changes the display would be done.
function execute_query($x)
{
	$dbhost = "localhost";
	$dbuser = "root";
	$dbpass = "";
	//$dbname = "software_eng";
	$dbname = "se_project";
	error_reporting(E_ALL ^ E_DEPRECATED); // remove warning of deprication
	//Connect to MySQL Server
	mysql_connect($dbhost, $dbuser, $dbpass);
	//Select Database
	mysql_select_db($dbname) or die(mysql_error());
	// Retrieve data from Query String
	$dname = $_GET['dname1'];
	
	//New Code
	$query = "select Project_id from baseline where R_id = '$dname'";
	$qry_result = mysql_query($query) or die(mysql_error());
	$row = mysql_fetch_array($qry_result);
	$projectId = $row['Project_id'];
	$length = strlen($projectId);
	$splitRid = str_split($dname,$length);
	$count = count($splitRid);
	if($count == 3)
	{
		$dname1 = $splitRid[1].$splitRid[2];
	}
	else
	{
		$dname1 = $splitRid[1];
	}
	
	//build query
	if($x == ''){
		die( "You did not enter any value for n");
		return;
	}
	
	if($x >= 0){
		$query = "SELECT R_id,Pm_id,Description,Timestamp from baseline where R_id LIKE ('$dname') OR R_id LIKE ('%$dname1.%') ORDER BY Timestamp desc limit $x ";
	}
	else if($x == -1){
		$query = "SELECT R_id,Pm_id,Description,Timestamp from baseline where R_id LIKE ('%$dname1.%') OR R_id LIKE ('$dname') ORDER BY Timestamp desc";
	}
	else if($x == -2){
		$query = "SELECT R_id,Pm_id,Description,Timestamp from baseline where (R_id LIKE ('%$dname1.%') OR R_id LIKE ('$dname')) and Timestamp between '".$_GET['from']."' and '".$_GET['to']."' ORDER BY Timestamp desc";
	}
	else{
		die( "You did not enter any value ");
	}
	//Execute query
	$qry_result = mysql_query($query) or die(mysql_error());
	return $qry_result;
}

if((isset($_GET['options'])) && $_GET['options'] == 'nchanges')
{
//check for the number and then send the R_id,project manager,description.
//echo $_GET['nchanges'];// to check whether the nchanges is selected or not.
$x=$_GET['changes']; //input by the user
// total number if tables shown on the screen
$y=$_GET['counts'];

if($x == '')
{
die( "you didn't enter any value");
}
else if($x > $y)
{
die("enter the correct number of changes");
}
else{
$reqid=array();
$qry_result = execute_query($x);
while($row = mysql_fetch_array($qry_result)){
   $req_id = "$row[R_id]";
   array_push($reqid,$req_id);
   
   //$Progrm_id = "$row[Pm_id]";
   //$details = "$row[Description]";
   echo "$req_id <br>";

   
}
 print_r($reqid);
 $_SESSION['req_arr']=$reqid;
	$_SESSION['total']=count($reqid);
}
//echo $req_id;
}
else if((isset($_GET['options'])) && $_GET['options'] == 'datechanges')
{
	$from = $_GET['from'];
	$to =$_GET['to'];
	if($to == '' || $from == '')
		{die("select a date");}
	$qry_result = execute_query(-2);
	$reqid=array();
	while($row = mysql_fetch_array($qry_result)){
		//$timestamp = $row['Timestamp'];
		$req_id = "$row[R_id]";
		//$Progrm_id = "$row[Pm_id]";
		//$details = "$row[Description]";
		//$arr = date_parse($timestamp);
		//echo $arr['year']."<br>";
		//echo $arr['month']."<br>";
		//echo $arr['day']."<br>";
		//echo $arr['day']." ".$date_from." ".($arr['day'] >= $date_from)."<br>";
		//echo "Hello<br>";
		//if($arr['year'] >= $year_from && $arr['year'] <= $year_to && $arr['month'] >= $arr_month["$month_from"] && $arr['month'] <= $arr_month["$month_to"] && $arr['day'] >= $date_from && $arr['day'] <= $date_to ){
			array_push($reqid,$req_id);
			echo "$req_id<br>";
		
	}
	print_r($reqid);
	$_SESSION['req_arr']=$reqid;
	$_SESSION['total']=count($reqid);
}
//for all changes.
else if((isset($_GET['options'])) && $_GET['options'] == 'forall')
{
//Execute query
$qry_result = execute_query(-1);
$reqid=array();
while($row = mysql_fetch_array($qry_result)){
   
   $req_id = "$row[R_id]";
   array_push($reqid,$req_id);
   //$Progrm_id = "$row[Pm_id]";
   //$details = "$row[Description]";
   echo "$req_id <br>";
}
print_r($reqid);
$_SESSION['req_arr']=$reqid;
$_SESSION['total']=count($reqid);
}
else{
	//header("Location:entry.php");
	die( "select one option from ");
}
header("Location:changemodel.php");

?>