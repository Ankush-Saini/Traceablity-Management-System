This demonstrates a GoJS diagram in an NW.js app.

First, assuming you already have npm and git:
```
$ npm install gojs
```

Second, install NW.js.

Start app with:
```
$ path/to/nw .
```
