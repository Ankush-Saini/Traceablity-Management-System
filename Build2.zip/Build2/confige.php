<?php
	$model_pm_conn=mysqli_connect("localhost","root","");
	if(!$model_pm_conn)
	{
		die("Couldn't Connect".mysqli_connect_error());
	}	
	else
	{	
		mysqli_select_db($model_pm_conn,"se_project");
	}	
?>